PAYMENT & DEPOSIT MANAGEMENT

Upload ZIP to /home/deploy/hut-reservations and extract from that directory.

python install_payments.py
python manage.py makemigrations bookings
python manage.py migrate
python manage.py check
python manage.py test bookings

Only if all tests pass:
sudo systemctl restart gunicorn

IMPORTANT: Back up your production database before migrate. The installer backs up three modified files with .before_payments suffix. The migration creates a new payment table; existing reservations are unchanged.

Payment records are not edited/deleted through the staff UI. Refunds are separate entries. Only staff assigned to the reservation's hut (or superusers) can view/record transactions. Cancelled reservations can still receive refunds. Currency comes from BOOKING_CURRENCY; this version assumes one currency for all transactions.
