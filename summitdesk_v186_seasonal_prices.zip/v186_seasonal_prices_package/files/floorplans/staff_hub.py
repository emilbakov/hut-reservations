"""V27: unified, read-only, hut-scoped staff landing page."""
from .operations_summary_v93_v97 import sort_issues,sort_readiness,attention_totals,summary_csv
from .daily_tools_v88_v92 import search_issues, select_readiness, issues_csv, readiness_csv
from .daily_reports_v83_v87 import ISSUE_KINDS, filter_issues, arrival_readiness, bed_details_csv, checklist_csv
from .daily_workspace_v78_v82 import build_daily_workspace
from .operations_filters_v73_v77 import SORTS, select_actions, summarize_actions
from .operations_exports_v68_v72 import EXPORT_TYPES, PRIORITIES, filter_actions, operations_csv
from .manager_operations_v63_v67 import build_manager_operations
from .operations_v58_v62 import capacity_csv, build_room_operations
from .capacity_search_v57 import search_capacity_watch
from .capacity_filters_v56 import filter_capacity_watch
from .capacity_summary_v55 import summarize_capacity_watch
from .capacity_export_v54 import export_capacity_watch_csv
from .forecast_watch_v53 import build_capacity_watch
from .forecast_peaks_v52 import summarize_peaks
from .forecast_utilization_v51 import summarize_utilization
from .forecast_summary_v50 import summarize_forecast
from datetime import timedelta
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Sum
from django.http import HttpResponseForbidden
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.http import require_GET
from bookings.models import Room, ReservationItem
from .staff_tasks import access
from .housekeeping_tasks import HousekeepingTask
from .hut_staff import HutCleaner
from .staff_forecast_v38 import build_forecast
from .forecast_dates_v45 import select_forecast_start  # V45_FORECAST_DATES
from .forecast_comparison_v46 import compare_forecast  # V46_COMPARISON
from .comparison_highlights_v48 import build_comparison_highlights  # V48_COMPARISON_HIGHLIGHTS
from .comparison_export_v47 import export_comparison_csv  # V47_COMPARISON_EXPORT
from .forecast_export_v44 import export_forecast_csv  # V44_FORECAST_CSV
from .staff_alerts_v39 import build_alerts
from .alert_summary_v40 import summarize_alerts
from .alert_filters_v41 import filter_alerts
from .alert_search_v42 import search_alerts
from .alert_export_v43 import export_alerts_csv  # V43_CSV_EXPORT


@login_required
@require_GET
def staff_hub(request, hut_id):
    hut, manager, cleaner = access(request, hut_id)
    if not (manager or cleaner):
        return HttpResponseForbidden('Not authorized for this hut')
    today = timezone.localdate()
    # V63_V67_MANAGER_OPERATIONS: read-only, hut-scoped dedicated page.
    if manager and request.GET.get('operations') == '1':
        selected_start = select_forecast_start(request.GET.get('forecast_start'), today)
        operations = build_manager_operations(hut, selected_start)
        # DAILY_WORKSPACE_V78_V82: manager-only, hut-scoped, read-only.
        daily = build_daily_workspace(hut, selected_start, operations)
        # DAILY_REPORTS_V83_V87: manager-only; reuse computed hut-scoped data.
        issue_kind = request.GET.get('issue_kind', 'all')
        if issue_kind not in ISSUE_KINDS:
            issue_kind = 'all'
        visible_issues = filter_issues(daily['urgent'], issue_kind)
        issue_q = request.GET.get('issue_q', '').strip()[:100]
        visible_issues = search_issues(visible_issues, issue_q)
        issue_order = request.GET.get('issue_order','earliest')
        if issue_order not in ('earliest','latest','title'): issue_order='earliest'
        visible_issues = sort_issues(visible_issues,issue_order)
        readiness = arrival_readiness(daily['timeline'])
        readiness_mode = request.GET.get('readiness_mode', 'all')
        if readiness_mode not in ('all', 'review'):
            readiness_mode = 'all'
        readiness = select_readiness(readiness, readiness_mode)
        readiness_order = request.GET.get('readiness_order','earliest')
        if readiness_order not in ('earliest','latest','most_work'): readiness_order='earliest'
        readiness = sort_readiness(readiness,readiness_order)
        attention = attention_totals(visible_issues,readiness)
        daily_tools_export = request.GET.get('daily_tools_export', '')
        # OPERATIONS_SUMMARY_V93_V97
        if daily_tools_export == 'summary':
            return summary_csv(hut,visible_issues,readiness)
        if daily_tools_export == 'issues':
            return issues_csv(hut, visible_issues)
        if daily_tools_export == 'readiness':
            return readiness_csv(hut, readiness)
        daily_export = request.GET.get('daily_export', '')
        if daily_export == 'beds':
            return bed_details_csv(hut, daily)
        if daily_export == 'checklist':
            return checklist_csv(hut, daily)
        # V68_V72_EXPORTS: manager-only; reuse the hut-scoped operations dataset.
        action_level = request.GET.get('action_level', 'all')
        if action_level not in PRIORITIES:
            action_level = 'all'
        # V73_V77_ACTION_TOOLS: filters and CSV share the same result set.
        action_q = request.GET.get('action_q', '').strip()[:100]
        action_day = request.GET.get('action_day', '')
        valid_days = {d.isoformat() for d in operations['dates']}
        if action_day not in valid_days:
            action_day = ''
        action_sort = request.GET.get('action_sort', 'priority')
        if action_sort not in SORTS:
            action_sort = 'priority'
        displayed_actions = select_actions(
            filter_actions(operations['actions'], action_level),
            query=action_q, action_date=action_day, sort=action_sort,
        )
        action_summary = summarize_actions(displayed_actions)
        export_kind = request.GET.get('operations_export', '')
        if export_kind in EXPORT_TYPES:
            return operations_csv(hut, operations, export_kind, displayed_actions)
        return render(request, 'floorplans/manager_operations_v63_v67.html', {
            'hut': hut, 'today': today, 'forecast_start': selected_start,
            'forecast_max': today + timedelta(days=365), 'ops': operations, 'daily': daily,
            'issue_kind': issue_kind, 'visible_issues': visible_issues, 'readiness': readiness,
            'issue_q': issue_q, 'readiness_mode': readiness_mode,
            'issue_order':issue_order,'readiness_order':readiness_order,'attention':attention,
            'displayed_actions': displayed_actions, 'action_level': action_level,
            'action_q': action_q, 'action_day': action_day, 'action_sort': action_sort,
            'action_summary': action_summary,
        })
    tomorrow = today + timedelta(days=1)
    task_qs = HousekeepingTask.objects.filter(bed__room__hut=hut, day=today)
    if not manager:
        task_qs = task_qs.filter(assignee=request.user)
    counts = {key: task_qs.filter(status=key).count() for key in ('open', 'in_progress', 'done')}
    tasks = list(task_qs.select_related('bed__room', 'assignee').order_by('-priority', 'bed__room__name', 'bed__number')[:8])
    context = {'hut': hut, 'manager': manager, 'today': today, 'counts': counts,
               'tasks': tasks, 'task_total': sum(counts.values())}
    if manager:
        rooms = Room.objects.filter(hut=hut, is_active=True)
        items = ReservationItem.objects.filter(
            room__in=rooms, reservation__status__in=('confirmed', 'pending'),
        ).filter(Q(reservation__check_in__lte=today, reservation__check_out__gt=today)
                 | Q(reservation__check_in=today) | Q(reservation__check_out=today))
        context.update({
            'capacity': sum(rooms.values_list('capacity', flat=True)),
            'occupied_beds': items.filter(reservation__check_in__lte=today,
                                          reservation__check_out__gt=today).aggregate(total=Sum('beds'))['total'] or 0,
            'arrivals': items.filter(reservation__check_in=today).aggregate(total=Sum('beds'))['total'] or 0,
            'departures': items.filter(reservation__check_out=today).aggregate(total=Sum('beds'))['total'] or 0,
            'cleaner_count': HutCleaner.objects.filter(hut=hut).count(),
        })
    # V37_MANAGER_OVERVIEW: stay-date figures for today, confirmed bookings only.
    if manager:
        from decimal import Decimal
        daily_items = ReservationItem.objects.filter(
            room__hut=hut,
            room__is_active=True,
            reservation__status='confirmed',
        ).filter(
            Q(reservation__check_in__lte=today, reservation__check_out__gt=today)
            | Q(reservation__check_in=tomorrow)
        ).select_related('reservation')
        confirmed_today = 0
        confirmed_value_today = Decimal('0.00')
        arrivals_tomorrow = 0
        for item in daily_items:
            reservation = item.reservation
            if reservation.check_in <= today < reservation.check_out:
                confirmed_today += item.beds
                confirmed_value_today += item.nightly_total_on(today)
            if reservation.check_in == tomorrow:
                arrivals_tomorrow += item.beds
        context.update({
            'v37_confirmed_beds_today': confirmed_today,
            'v37_booking_value_today': confirmed_value_today,
            'v37_arrivals_tomorrow': arrivals_tomorrow,
        })
    # V38_FORECAST_START
    if manager:
        context['forecast_v38'] = build_forecast(hut, today)
        # V45_FORECAST_DATES: keep today's forecast for v39-v43 alerts.
        forecast_start = select_forecast_start(request.GET.get('forecast_start'), today)
        context['forecast_start_v45'] = forecast_start
        context['forecast_max_v45'] = today + timedelta(days=365)
        context['forecast_display_v45'] = (context['forecast_v38'] if forecast_start == today
                                           else build_forecast(hut, forecast_start))
        context['forecast_summary_v50'] = summarize_forecast(context['forecast_display_v45'])
        context['forecast_utilization_v51'] = summarize_utilization(context['forecast_display_v45'])
        context['forecast_peaks_v52'] = summarize_peaks(context['forecast_display_v45'])
        context['forecast_watch_v53'] = build_capacity_watch(context['forecast_display_v45'])
        context['capacity_level_v56'], context['capacity_filtered_v56'] = filter_capacity_watch(
            context['forecast_watch_v53'], request.GET.get('capacity_level'))
        context['capacity_query_v57'], context['capacity_results_v57'] = search_capacity_watch(
            context['capacity_filtered_v56'], request.GET.get('capacity_q'))
        # V58_V62_OPERATIONS: same filtered rows for screen and CSV.
        if request.GET.get('capacity_filtered_export') == 'csv':
            return capacity_csv(hut, context['capacity_results_v57'])
        context['room_operations_v62'] = build_room_operations(hut, context['forecast_start_v45'])
        context['capacity_summary_v55'] = summarize_capacity_watch(context['forecast_watch_v53'])
        context['capacity_export_start_v54'] = context['forecast_display_v45'][0]['day']
        if request.GET.get('capacity_watch_export') == 'csv':
            return export_capacity_watch_csv(hut, context['forecast_watch_v53'], context['capacity_export_start_v54'])
        context['comparison_v46'] = compare_forecast(hut, forecast_start, context['forecast_display_v45'])  # V46_COMPARISON
        context['comparison_highlights_v48'] = build_comparison_highlights(context['comparison_v46'])  # V48_COMPARISON_HIGHLIGHTS
        if request.GET.get('comparison_export') == 'csv':  # V47_COMPARISON_EXPORT
            return export_comparison_csv(hut, context['comparison_v46'])
        # V44_FORECAST_CSV: only accessible inside the manager-only branch.
        if request.GET.get('forecast_export') == 'csv':
            return export_forecast_csv(hut, context['forecast_display_v45'])
        # V39_ALERTS_START
        context['alerts_v39'] = build_alerts(hut, today, context['forecast_v38'])
        # V40_ALERT_SUMMARY_START
        context['alert_summary_v40'] = summarize_alerts(context['alerts_v39'])
        # V41_ALERT_FILTERS_START
        context['alert_filter_v41'] = filter_alerts(context['alerts_v39'], request.GET.get('alert_level', 'all'))
        # V42_ALERT_SEARCH
        context['alert_search_v42'] = search_alerts(context['alert_filter_v41'], request.GET.get('alert_q', ''))
        # V43_CSV_EXPORT: only managers reach this branch; reuse displayed filtered rows.
        if request.GET.get('alert_export') == 'csv':
            return export_alerts_csv(hut, context['alert_search_v42']['rows'])
        # V41_ALERT_FILTERS_END
        # V40_ALERT_SUMMARY_END
        # V39_ALERTS_END
    # V38_FORECAST_END
    return render(request, 'floorplans/staff_hub.html', context)
